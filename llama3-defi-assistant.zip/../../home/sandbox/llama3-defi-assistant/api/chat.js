export default async function handler(req, res) {
  const { message } = req.body;

  const response = await fetch('http://localhost:8000/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message })
  });

  const data = await response.json();
  res.status(200).json({ reply: data.reply });
}
