import React, { useState } from 'react';

export default function Home() {
  const [message, setMessage] = useState('');
  const [reply, setReply] = useState('');

  const sendMessage = async () => {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message })
    });
    const data = await res.json();
    setReply(data.reply);
  };

  return (
    <div className="p-4 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">🦙 LLaMA 3 DeFi Assistant</h1>
      <textarea
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="Ask a DeFi question..."
        className="w-full p-2 border rounded"
      />
      <button onClick={sendMessage} className="mt-2 bg-black text-white px-4 py-2 rounded">Send</button>
      {reply && (
        <div className="mt-4 p-2 border rounded bg-gray-100">
          <strong>Response:</strong>
          <p>{reply}</p>
        </div>
      )}
    </div>
  );
}
