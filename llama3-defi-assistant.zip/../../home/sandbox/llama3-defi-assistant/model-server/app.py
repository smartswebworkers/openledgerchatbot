from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from transformers import AutoModelForCausalLM, AutoTokenizer
import torch

app = FastAPI()
origins = ["*"]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_methods=["*"], allow_headers=["*"])

tokenizer = AutoTokenizer.from_pretrained("path/to/llama3", use_fast=True)
model = AutoModelForCausalLM.from_pretrained("path/to/llama3", device_map="auto", torch_dtype=torch.float16)

@app.post("/chat")
async def chat(request: Request):
    body = await request.json()
    message = body.get("message", "")
    inputs = tokenizer(message, return_tensors="pt").to(model.device)
    outputs = model.generate(**inputs, max_new_tokens=200)
    reply = tokenizer.decode(outputs[0], skip_special_tokens=True)
    return {"reply": reply}
